<?php
/**
 * কাস্টমার রসিদ/স্টেটমেন্ট — প্রিন্ট, PDF, ছবি, শেয়ার।
 * $ame_slip = [target, file, title, text, shop, links[]]
 */
if (!function_exists('ame_pair')) {
    function ame_pair(string $bn, string $en): string
    {
        return '<span class="ame-pair"><strong>' . htmlspecialchars($bn, ENT_QUOTES, 'UTF-8') . '</strong><em>' . htmlspecialchars($en, ENT_QUOTES, 'UTF-8') . '</em></span>';
    }
}

$ame_slip = is_array($ame_slip ?? null) ? $ame_slip : [];
$ver = htmlspecialchars(defined('AME_ASSET_VERSION') ? AME_ASSET_VERSION : '10.98.66', ENT_QUOTES, 'UTF-8');
$shop = (string) ($ame_slip['shop'] ?? (function_exists('shop_name') ? shop_name() : 'APONSHOP'));
$payload = [
    'target' => (string) ($ame_slip['target'] ?? '#ame-slip'),
    'file' => (string) ($ame_slip['file'] ?? 'receipt'),
    'title' => (string) ($ame_slip['title'] ?? ($shop . ' · receipt')),
    'text' => (string) ($ame_slip['text'] ?? ''),
    'shop' => $shop,
];
$links = is_array($ame_slip['links'] ?? null) ? $ame_slip['links'] : [];
?>
<link rel="stylesheet" href="/assets/css/customer-slip-share.css?v=<?php echo $ver; ?>">
<div class="ame-slip-bar no-print" id="ameSlipBar">
    <button type="button" class="ame-slip-btn" onclick="ameSlipPrint()"><?php echo ame_pair('প্রিন্ট', 'Print'); ?></button>
    <button type="button" class="ame-slip-btn" onclick="ameSlipPdf()"><?php echo ame_pair('PDF', 'PDF'); ?></button>
    <button type="button" class="ame-slip-btn" onclick="ameSlipImage()"><?php echo ame_pair('ছবি', 'Image'); ?></button>
    <button type="button" class="ame-slip-btn" onclick="ameSlipShareOpen()"><?php echo ame_pair('শেয়ার', 'Share'); ?></button>
    <?php foreach ($links as $link):
        if (empty($link['href']) || empty($link['html'])) {
            continue;
        }
        $ghost = !empty($link['ghost']);
        ?>
    <a class="ame-slip-btn<?php echo $ghost ? ' ghost' : ''; ?>" href="<?php echo htmlspecialchars((string) $link['href'], ENT_QUOTES, 'UTF-8'); ?>"><?php echo $link['html']; ?></a>
    <?php endforeach; ?>
</div>
<div class="ame-slip-sheet no-print" id="ameSlipSheet" hidden>
    <div class="ame-slip-card" role="dialog" aria-label="Share">
        <div class="ame-slip-head">
            <strong><?php echo ame_pair('শেয়ার করুন', 'Share this slip'); ?></strong>
            <button type="button" class="ame-slip-x" onclick="ameSlipShareClose()" aria-label="Close">&times;</button>
        </div>
        <p class="ame-slip-hint"><?php echo ame_pair(
            'ফোন, হোয়াটসঅ্যাপ ও টেলিগ্রামে শুধু পূর্ণ মেমোর পরিষ্কার ছবি যাবে। PDF আলাদাভাবে নামানো যাবে।',
            'Phone share, WhatsApp and Telegram receive the full memo as a clear image. PDF remains available as a download.'
        ); ?></p>
        <button type="button" class="ame-slip-opt" onclick="ameSlipShareNative()"><?php echo ame_pair('ফোনের শেয়ার', 'Phone share'); ?></button>
        <button type="button" class="ame-slip-opt" onclick="ameSlipShareWhatsApp()"><?php echo ame_pair('হোয়াটসঅ্যাপ', 'WhatsApp'); ?></button>
        <button type="button" class="ame-slip-opt" onclick="ameSlipImage()"><?php echo ame_pair('ছবি নামান', 'Download image'); ?></button>
        <button type="button" class="ame-slip-opt" onclick="ameSlipPdf()"><?php echo ame_pair('PDF নামান', 'Download PDF'); ?></button>
        <button type="button" class="ame-slip-opt" onclick="ameSlipShareCopy()"><?php echo ame_pair('লেখা কপি', 'Copy text'); ?></button>
        <div class="ame-slip-msg" id="ameSlipMsg" hidden></div>
    </div>
</div>
<div class="ame-slip-busy no-print" id="ameSlipBusy" hidden><?php echo htmlspecialchars(ame_l('তৈরি হচ্ছে…', 'Preparing…'), ENT_QUOTES, 'UTF-8'); ?></div>
<script>
window.AME_SLIP = <?php echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES); ?>;
window.AME_SHOP_NAME = <?php echo json_encode($shop, JSON_UNESCAPED_UNICODE); ?>;
</script>
<script src="/assets/js/html2canvas.min.js?v=<?php echo $ver; ?>"></script>
<script src="/assets/js/jspdf.umd.min.js?v=<?php echo $ver; ?>"></script>
<script src="/assets/js/customer-slip-share.js?v=<?php echo $ver; ?>" defer></script>
