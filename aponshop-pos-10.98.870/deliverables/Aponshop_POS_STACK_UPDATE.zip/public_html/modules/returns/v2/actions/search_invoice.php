<?php
require_once __DIR__ . '/../../../../includes/config.php';
require_once __DIR__ . '/../../../../includes/return_v2_functions.php';
ensure_return_v2_schema($db);

header('Content-Type: application/json; charset=UTF-8');

$invoice_no = trim($_GET['invoice_no'] ?? '');

if ($invoice_no === '') {
    echo json_encode(['status' => 'error', 'message' => 'ইনভয়েস নম্বর দিন।']);
    exit;
}

$stmt = $db->prepare(
    "SELECT s.id, s.invoice_number, s.sale_date, s.customer_id, s.customer_type,
            c.name as customer_name, c.phone as customer_phone, c.customer_code, c.receivable_balance
     FROM sales s
     LEFT JOIN customers c ON s.customer_id = c.id
     WHERE s.invoice_number = ? AND s.status = 'completed'"
);
$stmt->bind_param('s', $invoice_no);
$stmt->execute();
$sale = $stmt->get_result()->fetch_assoc();

if (!$sale) {
    echo json_encode(['status' => 'error', 'message' => 'এই নম্বরে কোনো সম্পন্ন ইনভয়েস পাওয়া যায়নি।']);
    exit;
}

$items_stmt = $db->prepare(
    "SELECT si.product_id, p.name as product_name, p.sale_price as retail_price, p.wholesale_price,
            p.dealer_price, si.qty as sold_qty, si.sale_price as unit_price
     FROM sale_items si
     JOIN products p ON si.product_id = p.id
     WHERE si.sale_id = ?"
);
$items_stmt->bind_param('i', $sale['id']);
$items_stmt->execute();
$item_rows = $items_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$items = [];
foreach ($item_rows as $it) {
    $already_returned = get_already_returned_qty($db, $sale['id'], (int)$it['product_id']);
    $items[] = [
        'product_id' => (int)$it['product_id'],
        'product_name' => $it['product_name'],
        'sold_qty' => (float)$it['sold_qty'],
        'already_returned' => $already_returned,
        'unit_price' => (float)$it['unit_price'],
        'retail_price' => (float)$it['retail_price'],
        'wholesale_price' => (float)$it['wholesale_price'],
        'dealer_price' => (float)($it['dealer_price'] ?? 0),
    ];
}

echo json_encode([
    'status' => 'success',
    'sale' => [
        'id' => (int)$sale['id'],
        'invoice_number' => $sale['invoice_number'],
        'sale_date' => date('d-m-Y', strtotime($sale['sale_date'] ?? 'now')),
        'customer_id' => $sale['customer_id'] ? (int)$sale['customer_id'] : null,
        'customer_name' => $sale['customer_name'] ?: 'Retail Customer',
        'customer_code' => $sale['customer_code'] ?? '',
        'customer_phone' => $sale['customer_phone'] ?? '',
        'customer_balance' => (float)($sale['receivable_balance'] ?? 0),
        'sales_type' => (strtolower((string)$sale['customer_type']) === 'wholesale') ? 'wholesale' : 'retail',
    ],
    'items' => $items,
], JSON_UNESCAPED_UNICODE);
